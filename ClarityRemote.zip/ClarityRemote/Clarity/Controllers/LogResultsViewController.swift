//
//  LogResultsViewController.swift
//  Clarity
//
//  Created by Kamalika Kummathi on 8/3/21.
//

import UIKit

class LogResultsViewController: UIViewController {

    @IBOutlet weak var determineScore: UILabel!
    @IBOutlet weak var recBased: UILabel!
    var score = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        print(score)
        determineScore.text = ("\(score)")
    
        if(score >= 9 && score <= 18){
            recBased.text = ("It looks like you were minimally stressed today. Consider taking two minutes to breathe and relax.")
        }
        else if(score >= 19 && score <= 27){
            recBased.text = ("It looks like you were relatively stressed today. Consider taking five minutes to breathe and relax.")
        }
        else if(score >= 28 && score <= 36){
            recBased.text = ("It looks like you were very stressed today. Consider taking ten minutes to breathe and relax.")
        }
        else{
            recBased.text = ("I don't think you completed the quiz.")
        }
      
    
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

